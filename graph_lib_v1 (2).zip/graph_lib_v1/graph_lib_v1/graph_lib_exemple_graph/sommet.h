#ifndef SOMMET_H_INCLUDED
#define SOMMET_H_INCLUDED

class Sommet()
{
private :

};

#endif // SOMMET_H_INCLUDED
