#ifndef ARETE_H_INCLUDED
#define ARETE_H_INCLUDED

class Arete
{
private :
    int m_s1;
    int m_s2;
    int m_poids;

public :
    Arete();
    ~Arete();
    Arete(int _s1, int _s2, int _poids );
};


#endif // ARETE_H_INCLUDED
