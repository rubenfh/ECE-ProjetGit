#include "grman/grman.h"
#include <iostream>

#include "graph.h"
#include <allegro.h>

void menu();

int main()
{

    /// A appeler en 1er avant d'instancier des objets graphiques etc...
    grman::init();

    Graph g;
    menu();




    /*int choix;
    std::cout<<"Choisir graphe"<<std::endl;
    std::cout<<"1.Graphe 1"<<std::endl<<"2.Graphe 2"<<std::endl<<"3.Graphe 3"<<std::endl;
    std::cin>>choix;

    switch (choix)
    {
    case 1:

        g.make_example();
        break;

    case 2:

        g.make_example2();
        break;

    case 3:

        g.make_example3();
        break;
    }

    while (!key[KEY_ESC])
    {

    /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
        g.update();

        /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
        grman::mettre_a_jour();
    }
    /// Vous gardez la main sur la "boucle de jeu"
    /// ( contrairement � des frameworks plus avanc�s )
    */

      grman::fermer_allegro();

return 0;

}

END_OF_MAIN();


void menu()
{
    BITMAP *page;
    BITMAP *image;
    page=create_bitmap(800,600);
    image=load_bitmap("menu.bmp",NULL);
    Graph g;
     bool booleen = false;
grman::set_pictures_path("pics");


    while (!key[KEY_ESC])
    {

        blit(image,page,0,0,0,0,800,600);
        blit(page,screen,0,0,0,0,800,600);
        grman::set_pictures_path("pics");
        //g.make_example();



        if (mouse_b&1 && mouse_x>300 && mouse_x<492 && mouse_y>142 && mouse_y<214 )
        {

            booleen = true;
            g.make_example();
            while (booleen == true)
            {
                g.update();
                grman::mettre_a_jour();
                //g.make_example();
                if(key[KEY_S])
                    {

                    g.savecoord1();
                    }
                //std::cout<<"papa";
                if(key[KEY_P])
                {

                    booleen=false;
                    blit(image,page,0,0,0,0,800,600);
                    blit(page,screen,0,0,0,0,800,600);
                    menu();

                }

            }

        }

        else if (mouse_b&1 && mouse_x>300 && mouse_x<492 && mouse_y>231 && mouse_y<304 )
        {
            booleen = true;
            g.make_example2();
            while (booleen == true)
            {
                g.update();
                grman::mettre_a_jour();

            if(key[KEY_S])
                {
                    booleen=false;
                    blit(image,page,0,0,0,0,800,600);
                    blit(page,screen,0,0,0,0,800,600);
                    menu();

                }
            }


        }

        else if (mouse_b&1 && mouse_x>300 && mouse_x<492 && mouse_y>324 && mouse_y<395)
        {
            booleen = true;
            g.make_example3();
            while (booleen == true)
            {
                g.update();
                grman::mettre_a_jour();

                if(key[KEY_S])
                {
                    booleen=false;
                    blit(image,page,0,0,0,0,800,600);
                    blit(page,screen,0,0,0,0,800,600);
                    menu();

                }
            }


        }

    }

}


