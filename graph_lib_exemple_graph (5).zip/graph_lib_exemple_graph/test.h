#ifndef TEST_H_INCLUDED
#define TEST_H_INCLUDED

#include "grman/grman.h"
#include <iostream>
#include <stack>

/***************************************************
                    THING (test)

  Cette classe correspond au cadre en bas � gauche
  avec diff�rents bidules interactifs assembl�s dessus
  VOIR LE CONSTRUCTEUR ET LA METHODE UPDATE EN DETAIL
  ( dans test.cpp ) pour d�crypter l'utilisation
  des widgets propos�s ( vous pouvez en ajouter d'autres
  en compl�tant widget.h et widget.cpp, r�pertoire
  de projet grman )
****************************************************/
class Thing {

    private :
        /// Utiliser une top_box de type WidgetBox pour encapsuler
        /// tous les �l�ments de l'interface associ�s � votre objet
        grman::WidgetBox m_top_box;

        grman::WidgetButton m_bouton_ajout; //Bouton avec l'image ajouter
        grman::WidgetText m_image_ajout; //image ajouter


        public:

        /// Le constructeur de la classe (pas forc�ment par d�faut !)
        /// initialise les donn�es des widgets, place la hi�rarchie des sous-cadres etc...
        Thing();

        /// Une m�thode "update" de la classe doit �tre appel�e dans la boucle de jeu
        /// et cette m�thode doit propager l'appel � update sur les widgets contenus...
        /// Cette m�thode fait le lien entre l'interface, les �v�nements, et les cons�quences
        //  ( Cette m�thode pourrait s'appeler autrement, avoir des param�tres... )
        void update();

        /// On a des allocations dynamiques dans m_dynaclowns => � nettoyer dans le destructeur
        ~Thing();

};


#endif // TEST_H_INCLUDED


