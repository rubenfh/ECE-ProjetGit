#include "grman/grman.h"
#include <iostream>

#include "test.h"

#include "graph.h"
#include <allegro.h>

void menu();
void bibli( Graph &g);

int main()
{

    /// A appeler en 1er avant d'instancier des objets graphiques etc...
    grman::init();

    Graph g;
    menu();




    /*int choix;
    std::cout<<"Choisir graphe"<<std::endl;
    std::cout<<"1.Graphe 1"<<std::endl<<"2.Graphe 2"<<std::endl<<"3.Graphe 3"<<std::endl;
    std::cin>>choix;

    switch (choix)
    {
    case 1:

        g.make_example();
        break;

    case 2:

        g.make_example2();
        break;

    case 3:

        g.make_example3();
        break;
    }

    while (!key[KEY_ESC])
    {

    /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
        g.update();

        /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
        grman::mettre_a_jour();
    }
    /// Vous gardez la main sur la "boucle de jeu"
    /// ( contrairement � des frameworks plus avanc�s )
    */

      grman::fermer_allegro();

return 0;

}

END_OF_MAIN();


void menu()
{
    BITMAP *page;
    BITMAP *image;
    page=create_bitmap(800,600);
    image=load_bitmap("menu.bmp",NULL);
    Graph g;
     bool booleen = false;
grman::set_pictures_path("pics");


    while (!key[KEY_ESC])
    {

        blit(image,page,0,0,0,0,800,600);
        blit(page,screen,0,0,0,0,800,600);
        grman::set_pictures_path("pics");
        //g.make_example();



        if (mouse_b&1 && mouse_x>300 && mouse_x<492 && mouse_y>142 && mouse_y<214 )
        {

            booleen = true;
            g.make_example();

            while (booleen == true)
            {
                g.update();
                grman::mettre_a_jour();

                if (key[KEY_B])
                {
                    bibli( g);
                }
                //g.make_example();
                if(key[KEY_S])
                    {

                    g.save1();
                    }
                //std::cout<<"papa";

                if(key[KEY_T])
                    {
                        g.ajouter_arc();
                    }

                if(key[KEY_P])
                {

                    booleen=false;
                    blit(image,page,0,0,0,0,800,600);
                    blit(page,screen,0,0,0,0,800,600);
                    menu();

                }

            }

        }

        else if (mouse_b&1 && mouse_x>300 && mouse_x<492 && mouse_y>231 && mouse_y<304 )
        {
            booleen = true;
            g.make_example2();
            while (booleen == true)
            {
                g.update();
                grman::mettre_a_jour();

                if (key[KEY_B])
                    {
                        bibli( g);
                    }
                if(key[KEY_S])
                    {

                    g.save2();
                    }

                    if(key[KEY_T])
                    {
                        g.ajouter_arc();
                    }

            if(key[KEY_P])
                {
                    booleen=false;
                    blit(image,page,0,0,0,0,800,600);
                    blit(page,screen,0,0,0,0,800,600);
                    menu();

                }
            }


        }

        else if (mouse_b&1 && mouse_x>300 && mouse_x<492 && mouse_y>324 && mouse_y<395)
        {
            booleen = true;
            g.make_example3();
            while (booleen == true)
            {
                g.update();
                grman::mettre_a_jour();
                if (key[KEY_B])
                    {
                        bibli( g);
                    }
                if(key[KEY_S])
                    {

                    g.save3();
                    }

                    if(key[KEY_T])
                    {
                        g.ajouter_arc();
                    }

                if(key[KEY_P])
                {
                    booleen=false;
                    blit(image,page,0,0,0,0,800,600);
                    blit(page,screen,0,0,0,0,800,600);
                    menu();

                }
            }


        }

    }

}


void bibli ( Graph &g)
{
    int x,y,n,m;
    srand (time(NULL));
    x=rand()%801;
    y=rand()%601;
    std::cout<<"voulez vous ajouter un sommet ? 1.oui 2.non"<<std::endl;
    std::cin>>m;

    if (m==1)
    {
std::cout<<"entrez la valeur du nouveau sommet"<<std::endl;
 std::cin>>n;
        do
        {
            BITMAP *image1;


            image1=load_bitmap("Ajout.bmp",NULL);
            blit(image1,screen,0,0,0,0,800,600);
        }
        while(!mouse_b&1);


        if (mouse_b&1 && mouse_x>28 && mouse_x<128 && mouse_y>55 && mouse_y<159)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "buffle.png");
        }
        if (mouse_b&1 && mouse_x>157 && mouse_x<257 && mouse_y>48 && mouse_y<173)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "chat_sauvage.png");
        }
        if (mouse_b&1 && mouse_x>289 && mouse_x<389 && mouse_y>71 && mouse_y<139)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "chenille.png");
        }
        if (mouse_b&1 && mouse_x>420 && mouse_x<520 && mouse_y>48 && mouse_y<165)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "elephant.png");
        }
        if (mouse_b&1 && mouse_x>549 && mouse_x<649 && mouse_y>67 && mouse_y<154)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "fourmi.png");
        }
        if (mouse_b&1 && mouse_x>673 && mouse_x<773 && mouse_y>55 && mouse_y<168)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "gazelle.png");
        }
        if (mouse_b&1 && mouse_x>25 && mouse_x<125 && mouse_y>190 && mouse_y<314)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "gnou.png");
        }
        if (mouse_b&1 && mouse_x>155 && mouse_x<255 && mouse_y>328 && mouse_y<492)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "lion.png");
        }
        if (mouse_b&1 && mouse_x>286 && mouse_x<386 && mouse_y>344 && mouse_y<454)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "mesange.png");
        }
        if (mouse_b&1 && mouse_x>414 && mouse_x<514 && mouse_y>327 && mouse_y<447)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "phacochere.png");
        }
        if (mouse_b&1 && mouse_x>541 && mouse_x<641 && mouse_y>328 && mouse_y<455)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "poule.png");
        }
        if (mouse_b&1 && mouse_x>673 && mouse_x<773 && mouse_y>309 && mouse_y<469)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "renard.png");
        }
        if (mouse_b&1 && mouse_x>25 && mouse_x<125 && mouse_y>498 && mouse_y<594)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "sauterelle.png");
        }
        if (mouse_b&1 && mouse_x>155 && mouse_x<255 && mouse_y>494 && mouse_y<595)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "singe.png");
        }
        if (mouse_b&1 && mouse_x>285 && mouse_x<385 && mouse_y>470 && mouse_y<597)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "zebre.png");
        }
        if (mouse_b&1 && mouse_x>413 && mouse_x<513 && mouse_y>495 && mouse_y<589)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "vipere.png");
        }
        if (mouse_b&1 && mouse_x>161 && mouse_x<261 && mouse_y>196 && mouse_y<312)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "grenouille.png");
        }
        if (mouse_b&1 && mouse_x>284 && mouse_x<384 && mouse_y>198 && mouse_y<309)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "leopard.png");
        }
         if (mouse_b&1 && mouse_x>405 && mouse_x<505 && mouse_y>202 && mouse_y<302)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "herbe.png");
        }
         if (mouse_b&1 && mouse_x>534 && mouse_x<636 && mouse_y>195 && mouse_y<302)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "hippo.png");
        }
        if (mouse_b&1 && mouse_x>671 && mouse_x<771 && mouse_y>195 && mouse_y<299)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "hyene.png");
        }
        if (mouse_b&1 && mouse_x>25 && mouse_x<125 && mouse_y>340 && mouse_y<438)
        {
                g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "guepard.png");
        }
    }

}


