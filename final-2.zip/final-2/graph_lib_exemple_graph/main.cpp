#include "grman/grman.h"
#include <iostream>

#include "test.h"

#include "graph.h"
#include <allegro.h>
#include <chrono>
#include <thread>

int menu();
void bibli( Graph &g);

int main()
{

    /// A appeler en 1er avant d'instancier des objets graphiques etc...
    grman::init();

    Graph g;
    menu();




    /*int choix;
    std::cout<<"Choisir graphe"<<std::endl;
    std::cout<<"1.Graphe 1"<<std::endl<<"2.Graphe 2"<<std::endl<<"3.Graphe 3"<<std::endl;
    std::cin>>choix;

    switch (choix)
    {
    case 1:

        g.make_example();
        break;

    case 2:

        g.make_example2();
        break;

    case 3:

        g.make_example3();
        break;
    }

    while (!key[KEY_ESC])
    {

    /// Il faut appeler les m�thodes d'update des objets qui comportent des widgets
        g.update();

        /// Mise � jour g�n�rale (clavier/souris/buffer etc...)
        grman::mettre_a_jour();
    }
    /// Vous gardez la main sur la "boucle de jeu"
    /// ( contrairement � des frameworks plus avanc�s )
    */

    grman::fermer_allegro();

    return 0;

}

END_OF_MAIN();


int menu()
{
    BITMAP *page;
    BITMAP *image;
    page=create_bitmap(1024,768);
    image=load_bitmap("fond.bmp",NULL);
    Graph g;
    bool booleen = false;
    grman::set_pictures_path("pics");
    int eidx;
    int choix;

    while (!key[KEY_ESC])
    {

        blit(image,page,0,0,0,0,1024,768);
        blit(page,screen,0,0,0,0,1024,768);
        grman::set_pictures_path("pics");
        //g.make_example();



        if (mouse_b&1 && mouse_x>89 && mouse_x<295 && mouse_y>656 && mouse_y<709 )
        {
            choix=1;
            booleen = true;
            g.make_example();
            while (booleen == true)
            {
                g.update(choix);
                grman::mettre_a_jour();

                if (mouse_b&1 && mouse_x>33 && mouse_x<92 && mouse_y>132 && mouse_y<191)
                {
                    bibli(g);
                }

                if(key[KEY_V])
                {
                    std::this_thread::sleep_for(std::chrono::milliseconds(100));
                    if(g.m_vertices[1].m_value<92 && g.m_vertices[1].m_value!=0)
                    {

                        g.m_vertices[1].m_value=(g.m_vertices[1].m_value)+8;

                    }

                    if(g.m_vertices[0].m_value<86 && g.m_vertices[0].m_value!=0)
                    {

                        g.m_vertices[0].m_value=(g.m_vertices[0].m_value)+14;

                    }

                    if(g.m_vertices[2].m_value<93 && g.m_vertices[2].m_value!=0)
                    {

                        g.m_vertices[2].m_value=(g.m_vertices[2].m_value)+ 3;

                    }



                }


                if(key[KEY_P])
                {
                    std::this_thread::sleep_for(std::chrono::milliseconds(100));
                    if(g.m_vertices[1].m_value>0)
                    {

                        g.m_vertices[1].m_value=(g.m_vertices[1].m_value)-8;

                    }


                    if(g.m_vertices[0].m_value>0)
                    {

                        g.m_vertices[0].m_value=(g.m_vertices[0].m_value)-2;

                    }

                    if(g.m_vertices[2].m_value>0)
                    {

                        g.m_vertices[2].m_value=(g.m_vertices[2].m_value)-14;

                    }


                }

                //g.make_example();
                //std::cout<<"papa";
                if(mouse_b&1 && mouse_x>33 && mouse_x<92 && mouse_y>203 && mouse_y<263)
                {
                    booleen=false;
                    blit(image,page,0,0,0,0,1024,768);
                    blit(page,screen,0,0,0,0,1024,768);
                    menu();

                }


            }

        }

        else if (mouse_b&1 && mouse_x>416 && mouse_x<615 && mouse_y>657 && mouse_y<709 )
        {
            choix=2;
            booleen = true;
            g.make_example2();
            while (booleen == true)
            {
                g.update(choix);
                grman::mettre_a_jour();

                if (mouse_b&1 && mouse_x>33 && mouse_x<92 && mouse_y>132 && mouse_y<191)
                {
                    bibli( g);
                }

                if(key[KEY_S])
                {

                    g.save2();
                }

                if(mouse_b&1 && mouse_x>33 && mouse_x<92 && mouse_y>203 && mouse_y<263)
                {

                    booleen=false;
                    blit(image,page,0,0,0,0,1024,768);
                    blit(page,screen,0,0,0,0,1024,768);
                    menu();
                }


            }
        }
        else if (mouse_b&1 && mouse_x>738 && mouse_x<938 && mouse_y>659 && mouse_y<708)
        {
            choix=3;
            booleen = true;
            g.make_example3();
            while (booleen == true)
            {
                g.update(choix);
                grman::mettre_a_jour();

                if (mouse_b&1 && mouse_x>33 && mouse_x<92 && mouse_y>132 && mouse_y<191)
                {
                    bibli(g);
                }

                if(key[KEY_S])
                {

                    g.save3();
                }

                if(mouse_b&1 && mouse_x>33 && mouse_x<92 && mouse_y>203 && mouse_y<263)
                {
                    booleen=false;
                    blit(image,page,0,0,0,0,1024,768);
                    blit(page,screen,0,0,0,0,1024,768);
                    menu();

                }
            }


        }

        else if(mouse_b&1 && mouse_x>0 && mouse_y>77 && mouse_y<161)
        {
            return 0;
        }

    }

}



void bibli ( Graph &g)
{
    int x,y,n,m;
    srand (time(NULL));
    x=rand()%(917)+108;
    y=rand()%769;
    std::cout<<"voulez vous ajouter un sommet ? 1.oui 2.non"<<std::endl;
    std::cin>>m;

    if (m==1)
    {
        std::cout<<"entrez la valeur du nouveau sommet"<<std::endl;
        std::cin>>n;
        do
        {
            BITMAP *image1;


            image1=load_bitmap("Ajout.bmp",NULL);
            blit(image1,screen,0,0,0,0,1024,768);
        }
        while(!mouse_b&1);


        if (mouse_b&1 && mouse_x>28 && mouse_x<128 && mouse_y>55 && mouse_y<159)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "buffle.png");
        }
        if (mouse_b&1 && mouse_x>157 && mouse_x<257 && mouse_y>48 && mouse_y<173)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "chat_sauvage.png");
        }
        if (mouse_b&1 && mouse_x>289 && mouse_x<389 && mouse_y>71 && mouse_y<139)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "chenille.png");
        }
        if (mouse_b&1 && mouse_x>420 && mouse_x<520 && mouse_y>48 && mouse_y<165)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "elephant.png");
        }
        if (mouse_b&1 && mouse_x>549 && mouse_x<649 && mouse_y>67 && mouse_y<154)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "fourmi.png");
        }
        if (mouse_b&1 && mouse_x>673 && mouse_x<773 && mouse_y>55 && mouse_y<168)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "gazelle.png");
        }
        if (mouse_b&1 && mouse_x>25 && mouse_x<125 && mouse_y>190 && mouse_y<314)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "gnou.png");
        }
        if (mouse_b&1 && mouse_x>155 && mouse_x<255 && mouse_y>328 && mouse_y<492)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "lion.png");
        }
        if (mouse_b&1 && mouse_x>286 && mouse_x<386 && mouse_y>344 && mouse_y<454)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "mesange.png");
        }
        if (mouse_b&1 && mouse_x>414 && mouse_x<514 && mouse_y>327 && mouse_y<447)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "phacochere.png");
        }
        if (mouse_b&1 && mouse_x>541 && mouse_x<641 && mouse_y>328 && mouse_y<455)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "poule.png");
        }
        if (mouse_b&1 && mouse_x>673 && mouse_x<773 && mouse_y>309 && mouse_y<469)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "renard.png");
        }
        if (mouse_b&1 && mouse_x>25 && mouse_x<125 && mouse_y>498 && mouse_y<594)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "sauterelle.png");
        }
        if (mouse_b&1 && mouse_x>155 && mouse_x<255 && mouse_y>494 && mouse_y<595)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "singe.png");
        }
        if (mouse_b&1 && mouse_x>285 && mouse_x<385 && mouse_y>470 && mouse_y<597)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "zebre.png");
        }
        if (mouse_b&1 && mouse_x>413 && mouse_x<513 && mouse_y>495 && mouse_y<589)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "vipere.png");
        }
        if (mouse_b&1 && mouse_x>161 && mouse_x<261 && mouse_y>196 && mouse_y<312)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "grenouille.png");
        }
        if (mouse_b&1 && mouse_x>284 && mouse_x<384 && mouse_y>198 && mouse_y<309)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "leopard.png");
        }
        if (mouse_b&1 && mouse_x>405 && mouse_x<505 && mouse_y>202 && mouse_y<302)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "herbe.png");
        }
        if (mouse_b&1 && mouse_x>534 && mouse_x<636 && mouse_y>195 && mouse_y<302)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "hippo.png");
        }
        if (mouse_b&1 && mouse_x>671 && mouse_x<771 && mouse_y>195 && mouse_y<299)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "hyene.png");
        }
        if (mouse_b&1 && mouse_x>25 && mouse_x<125 && mouse_y>340 && mouse_y<438)
        {
            g.add_interfaced_vertex(g.m_vertices.size(), n, x,  y, "guepard.png");
        }
    }

}


