#include "test.h"

/***************************************************
                    THING (test)

  Cette classe correspond au cadre en bas � gauche
  avec diff�rents bidules interactifs assembl�s dessus
  VOIR LE CONSTRUCTEUR ET LA METHODE UPDATE EN DETAIL
  ( dans test.cpp ) pour d�crypter l'utilisation
  des widgets propos�s ( vous pouvez en ajouter d'autres
  en compl�tant widget.h et widget.cpp, r�pertoire
  de projet grman )
****************************************************/

/// Le constructeur de la classe (pas forc�ment par d�faut !)
/// initialise les donn�es des widgets, place la hi�rarchie des sous-cadres etc...

/// Tous les widgets sont des attributs directs (PAS DES POINTEURS, PAS DE NEW)
/// de la classe encapsulante (ici Thing) de telle sorte qu'ils sont d�truits
/// automatiquement quand la classe Thing est d�truite.
Thing::Thing()
{
    /// Le cadre d'ensemble de l'interface; x y coin sup. gauche, largeur, hauteur
    /// Le fond sera gris clair et on pourra le bouger � la souris (drag & drop)
    m_top_box.set_frame(0,0, 20, 400);
    m_top_box.set_bg_color(GRISCLAIR);
    m_top_box.set_moveable();

    m_top_box.add_child (m_bouton_ajout);
    m_bouton_ajout.set_frame(-60,-90,32,30);
    m_bouton_ajout.add_child(m_image_ajout);
    m_image_ajout.set_message("NOUVEAU");

}

/// Une m�thode update de la classe doit �tre appel�e dans la boucle de jeu
/// et cette m�thode doit propager l'appel � update sur les widgets contenus...
/// Cette m�thode fait le lien entre l'interface, les �v�nements, et les cons�quences
void Thing::update()
{
    /// Si tous les widgets d�pendants de l'objet sont dans une top box
    /// alors ce seul appel suffit (la propagation d'updates se fait ensuite automatiquement)
    m_top_box.update();

    if(m_bouton_ajout.clicked())
    {
        std::cout<<"NOUVEAU ! "<<std::endl;
    }

}

Thing::~Thing()
{

}



