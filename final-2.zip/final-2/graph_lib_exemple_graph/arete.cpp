#include "arete.h"

/*Arete::Arete(int _s1, int _s2, int _poids)
      :m_s1(0), m_s2(0), m_poids(0)
{

}

Arete::Arete(int _s1, int _s2, int _poids)
      :m_s1(_s1),m_s2(_s2),m_poids(_poids)
{

}

Arete::~Arete()
{

}

*/

